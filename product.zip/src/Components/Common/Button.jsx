import React from 'react';

const Button = ({type, label,className}) => {
    return (
        <div className="form-group row">
            <div class="col-md-4 offset-md-4">
            <button type={type} className={className}>{label}</button>
            </div>
        </div>
    );
};

export default Button;