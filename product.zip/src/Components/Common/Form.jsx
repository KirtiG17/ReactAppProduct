import React, { Component } from 'react';
import Joi from 'joi-browser';
import Input from './Input';

class Form extends Component {
    
    state = {
        data : {},
        errors : {}
    }

    renderInput = (name, value, label, placeholder, error, type='text')=>{
        return  <Input
                    name={name}
                    value={value}
                    type={type}
                    label={label}
                    placeholder={placeholder}
                    error={error}
                    onChange={this.handleChange} />
    }

    validateProperty = ({name, value})=>{
        const obj = { [name] : value }
        const scm = { [name] : this.schema[name]}
        const results = Joi.validate(obj, scm )
        
        return results.error ? results.error.details[0].message : null;
    }

    handleChange = ({currentTarget:input})=>{
        const errors = {...this.state.errors}
        const errorMessage = this.validateProperty(input)
        
        if(errorMessage)
            errors[input.name] = errorMessage;
        else 
            delete errors[input.name]

        const data = {...this.state.data}
        data[input.name] = input.value;

        this.setState({
            data,
            errors
        })
    }

    validate = ()=>{
        const {data} = this.state;

        const {error} = Joi.validate(data, this.schema, {abortEarly:false})
        if(!error) return null
        
        const errors = {};
        console.log(error.details)

        for(let item of error.details){
            errors[item.path[0]] = item.message;
        }

        return errors;
    }

    
    handleSubmit = (event)=>{
        event.preventDefault()

        const errors =  this.validate()
        //console.log(errors)
        this.setState({errors:errors || {} })

        if(errors) return;

        this.doSubmit();   
    }

}

export default Form;