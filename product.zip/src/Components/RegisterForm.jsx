import React from 'react';
import Form from './Common/Form';
import Joi from 'joi-browser';
import Button from './Common/Button';

class RegisterForm extends Form {

    state = {
        data : {email : '', name : '', password : ''},
        errors : {}
    }

    schema = {
        email : Joi.string().email().required(),
        name : Joi.string().required(),
        password : Joi.string().required() 
    }

    doSubmit = ()=>{
        //communicate to server..
        console.log('Submitted...')
    }

    render() {
        const {data, errors} = this.state;
        return (
            <div>
                <form onSubmit={this.handleSubmit}>

                {this.renderInput('email', data.email, "Email", "Enter Email", errors.email, "email")}
                {this.renderInput('name', data.name, "Name", "Enter Name", errors.name)}
                {this.renderInput('password', data.password, "Password", "Enter Password", errors.password, "password")}

                <Button label='Register' />

                </form>
            </div>
        );
    }
}

export default RegisterForm;