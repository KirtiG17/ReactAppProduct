import React, { Component } from 'react';
import {Button, Modal, ModalHeader, ModalFooter, ModalBody, Label, Input, FormGroup} from 'reactstrap';
import axios from 'axios';

const apiEndPoint = "https://jsonplaceholder.typicode.com/posts";

class Product extends Component {
    state = {
        products:[],
        newProductData:{
          title:'',
          body:''
        },
        editProductData:{
          userId:'',
          id:'',
          title:'',
          body:''
        },
        newProduct : false,
        editProductToggle : false
      }
  
      componentDidMount = () => {
          axios.get(apiEndPoint)
          .then(response => {
              const products = response.data;
              this.setState({products});
          })
      }
      componentWillMount(){
        this._refreshProduct();
      }
  
      addProduct=()=>{
        axios.post(apiEndPoint,this.state.newProductData).then(response=>{
          let { products } = this.state;
          products.push(response.data);
          this.setState({
            products,
            newProduct:false
          })
        })
      }

      editProduct=product=>{
        const id = product.id;
        const title = product.title;
        const body = product.body;
        this.setState({
          editProductData:{id,title,body},
          editProductToggle : !this.state.editProductToggle
        })
      }

      updateProduct(){        
        let {title,body}=this.state.editProductData;
        alert("Product Name : "+ title +"  Product Description :"+ body )
        axios.put(apiEndPoint + '/' + this.state.editProductData.id,{title,body}).then(response=>{
          this._refreshProduct()
        })
        this.setState({        
          editProductToggle : !this.state.editProductToggle
        })
      }
      
      
      deleteProduct = async product => {
        const originalProducts = [...this.state.products]  
        const products = this.state.products.filter(p=>p.id !== product.id)
        this.setState({products})      
        try{
           await axios.delete(apiEndPoint + '/' + product.id)
        }catch(ex){  
            if(ex.response && ex.response.status === 404)
              alert('This product has already deleted...')          
            this.setState({products:originalProducts})
        }
     
      };
      
      _refreshProduct(){
        axios.get(apiEndPoint)
          .then(response => {
              const products = response.data;
              this.setState({products});
          })
      }

      toggleNewProductModal = () => {
        this.setState({
          newProduct: !this.state.newProduct})
      }

      toggleEditProductModal = () => {
        this.setState({
          editProductToggle: !this.state.editProductToggle})
      }
  
      render() {
          let products = this.state.products.map(product =>                     
            <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.userId}</td>
                <td>{product.title}</td>
                <td>{product.body}</td>
                <td>
                <button type="button" className="btn btn-primary btn-sm m-1 buttonWidth" onClick={() => this.editProduct(product)}>Update</button>
                <button type="button" className="btn btn-danger btn-sm m-1 buttonWidth" onClick={() => this.deleteProduct(product)}>Delete</button>
                </td>
            </tr>
        )
          return (
              <div>
                  {/* Add */}
                  <Button color="success m-1" onClick={this.toggleNewProductModal}>Add new product</Button>
                  <Modal isOpen={this.state.newProduct} fade={false} toggle={this.toggleNewProductModal}>
                    <ModalHeader toggle={this.toggleNewProductModal}>Add a new product</ModalHeader>
                    <ModalBody>
                      <FormGroup>        
                        <Label for="name">Product Name</Label>
                        <Input type="text" value={this.state.newProductData.title} onChange={(e)=>{
                          let {newProductData} = this.state;
                          newProductData.title = e.target.value;
                          this.setState({newProductData})
                        }}/>
                        <Label for="body">Product Description</Label>
                        <Input type="text" value={this.state.newProductData.body} onChange={(e)=>{
                          let {newProductData} = this.state;
                          newProductData.body = e.target.value;
                          this.setState({newProductData})
                        }}/>
                      </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                    <Button color="primary" onClick={this.addProduct}>Add</Button>{' '}
                    <Button color="secondary" onClick={this.toggleNewProductModal}>Cancel</Button>
                   </ModalFooter>
                  </Modal>
  
                  {/* Update  */}
                  <Modal isOpen={this.state.editProductToggle} fade={false} toggle={this.toggleEditProductModal.bind(this)}>
                    <ModalHeader toggle={this.toggleEditProductModal}>Update Product detail</ModalHeader>
                    <ModalBody>
                      <FormGroup>     
                      <Label for="id">Product Id</Label>
                        <Input type="text" value={this.state.editProductData.id} onChange={(e)=>{
                          let {editProductData} = this.state;
                          editProductData.id = e.target.value;
                          this.setState({editProductData})
                        }}/>
                        <Label for="name">Product Name</Label>
                        <Input type="text" value={this.state.editProductData.title} onChange={(e)=>{
                          let {editProductData} = this.state;
                          editProductData.title = e.target.value;
                          this.setState({editProductData})
                        }}/>
                        <Label for="body">Product Description</Label>
                        <Input type="text" value={this.state.editProductData.body} onChange={(e)=>{
                          let {editProductData} = this.state;
                          editProductData.body = e.target.value;
                          this.setState({editProductData})
                        }}/>
                      </FormGroup>
                    </ModalBody>
                    <ModalFooter>
                    <Button color="primary" onClick={this.updateProduct.bind(this)}>Update</Button>{' '}
                    <Button color="secondary" onClick={this.toggleEditProductModal.bind(this)}>Cancel</Button>
                   </ModalFooter>
                  </Modal>
  
                  <table className="table">
                      <thead className="thead-light">
                          <tr>
                              <th>Product Id</th>
                              <th>User Id</th>
                              <th>Product Name</th>
                              <th>Product Description</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                      {products}
                      </tbody>
                  </table>
                  
              </div>
          );
      }
  }

export default Product;